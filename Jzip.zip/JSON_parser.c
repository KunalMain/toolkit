
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>

typedef enum {
    J_NULL, J_BOOL, J_NUMBER, J_STRING, J_ARRAY, J_OBJECT
} JType;

typedef struct JVal JVal;

typedef struct {
    char *key;
    JVal *value;
} JPair;

struct JVal {
    JType type;
    union {
        int boolean;
        double number;
        char *string;
        struct {
            JVal **items;
            size_t count;
        } array;
        struct {
            JPair *items;
            size_t count;
        } object;
    } as;
};

typedef struct {
    const char *p;
    const char *error;
} Parser;

static void ws(Parser *p) {
    while (isspace((unsigned char)*p->p))
        p->p++;
}

static JVal *newval(JType t) {
    JVal *v = calloc(1, sizeof *v);
    if (v) v->type = t;
    return v;
}

static void freeval(JVal *v) {
    if (!v) return;

    if (v->type == J_STRING) {
        free(v->as.string);
    } else if (v->type == J_ARRAY) {
        for (size_t i = 0; i < v->as.array.count; i++)
            freeval(v->as.array.items[i]);
        free(v->as.array.items);
    } else if (v->type == J_OBJECT) {
        for (size_t i = 0; i < v->as.object.count; i++) {
            free(v->as.object.items[i].key);
            freeval(v->as.object.items[i].value);
        }
        free(v->as.object.items);
    }

    free(v);
}

static char *parse_string(Parser *p) {
    if (*p->p != '"') return NULL;
    p->p++;

    size_t cap = 32, n = 0;
    char *s = malloc(cap);
    if (!s) return NULL;

    while (*p->p && *p->p != '"') {
        unsigned char c = (unsigned char)*p->p++;

        if (c < 0x20) goto fail;

        if (c == '\\') {
            c = (unsigned char)*p->p++;
            switch (c) {
                case '"':  c = '"';  break;
                case '\\': c = '\\'; break;
                case '/':  c = '/';  break;
                case 'b':  c = '\b'; break;
                case 'f':  c = '\f'; break;
                case 'n':  c = '\n'; break;
                case 'r':  c = '\r'; break;
                case 't':  c = '\t'; break;
                default:
                    /* Unicode escapes require additional handling. */
                    goto fail;
            }
        }

        if (n + 2 > cap) {
            if (cap > (size_t)-1 / 2) goto fail;
            cap *= 2;
            char *tmp = realloc(s, cap);
            if (!tmp) goto fail;
            s = tmp;
        }
        s[n++] = (char)c;
    }

    if (*p->p != '"') goto fail;
    p->p++;
    s[n] = '\0';
    return s;

fail:
    free(s);
    p->error = "Invalid or unsupported string escape";
    return NULL;
}

static JVal *parse_value(Parser *p);

static JVal *parse_array(Parser *p) {
    p->p++;
    JVal *v = newval(J_ARRAY);
    if (!v) return NULL;

    ws(p);
    if (*p->p == ']') {
        p->p++;
        return v;
    }

    for (;;) {
        JVal *item = parse_value(p);
        if (!item) goto fail;

        size_t n = v->as.array.count;
        JVal **tmp = realloc(v->as.array.items,
                             (n + 1) * sizeof *tmp);
        if (!tmp) {
            freeval(item);
            goto fail;
        }

        v->as.array.items = tmp;
        v->as.array.items[n] = item;
        v->as.array.count++;

        ws(p);
        if (*p->p == ']') {
            p->p++;
            return v;
        }
        if (*p->p != ',') goto fail;

        p->p++;
        ws(p);
    }

fail:
    if (!p->error) p->error = "Invalid array";
    freeval(v);
    return NULL;
}

static JVal *parse_object(Parser *p) {
    p->p++;
    JVal *v = newval(J_OBJECT);
    if (!v) return NULL;

    ws(p);
    if (*p->p == '}') {
        p->p++;
        return v;
    }

    for (;;) {
        char *key = parse_string(p);
        if (!key) goto fail;

        ws(p);
        if (*p->p != ':') {
            free(key);
            goto fail;
        }
        p->p++;
        ws(p);

        JVal *value = parse_value(p);
        if (!value) {
            free(key);
            goto fail;
        }

        size_t n = v->as.object.count;
        JPair *tmp = realloc(v->as.object.items,
                             (n + 1) * sizeof *tmp);
        if (!tmp) {
            free(key);
            freeval(value);
            goto fail;
        }

        v->as.object.items = tmp;
        v->as.object.items[n].key = key;
        v->as.object.items[n].value = value;
        v->as.object.count++;

        ws(p);
        if (*p->p == '}') {
            p->p++;
            return v;
        }
        if (*p->p != ',') goto fail;

        p->p++;
        ws(p);
    }

fail:
    if (!p->error) p->error = "Invalid object";
    freeval(v);
    return NULL;
}

static JVal *parse_number(Parser *p) {
    const char *start = p->p;
    char *end;

    if (*p->p == '-') p->p++;

    if (*p->p == '0') {
        p->p++;
        if (isdigit((unsigned char)*p->p)) goto fail;
    } else {
        if (*p->p < '1' || *p->p > '9') goto fail;
        while (isdigit((unsigned char)*p->p)) p->p++;
    }

    if (*p->p == '.') {
        p->p++;
        if (!isdigit((unsigned char)*p->p)) goto fail;
        while (isdigit((unsigned char)*p->p)) p->p++;
    }

    if (*p->p == 'e' || *p->p == 'E') {
        p->p++;
        if (*p->p == '+' || *p->p == '-') p->p++;
        if (!isdigit((unsigned char)*p->p)) goto fail;
        while (isdigit((unsigned char)*p->p)) p->p++;
    }

    {
        size_t len = (size_t)(p->p - start);
        char *buf = malloc(len + 1);
        if (!buf) return NULL;

        memcpy(buf, start, len);
        buf[len] = '\0';

        double x = strtod(buf, &end);
        int valid = (*end == '\0' && isfinite(x));
        free(buf);

        if (!valid) goto fail;

        JVal *v = newval(J_NUMBER);
        if (v) v->as.number = x;
        return v;
    }

fail:
    p->error = "Invalid JSON number";
    return NULL;
}

static JVal *parse_value(Parser *p) {
    ws(p);

    if (*p->p == '{') return parse_object(p);
    if (*p->p == '[') return parse_array(p);

    if (*p->p == '"') {
        char *s = parse_string(p);
        if (!s) return NULL;

        JVal *v = newval(J_STRING);
        if (!v) {
            free(s);
            return NULL;
        }
        v->as.string = s;
        return v;
    }

    if (*p->p == '-' || isdigit((unsigned char)*p->p))
        return parse_number(p);

    struct {
        const char *word;
        JType type;
        int boolean;
    } literals[] = {
        {"true", J_BOOL, 1},
        {"false", J_BOOL, 0},
        {"null", J_NULL, 0}
    };

    for (size_t i = 0; i < 3; i++) {
        size_t n = strlen(literals[i].word);
        if (strncmp(p->p, literals[i].word, n) == 0) {
            p->p += n;
            JVal *v = newval(literals[i].type);
            if (v) v->as.boolean = literals[i].boolean;
            return v;
        }
    }

    p->error = "Unexpected token";
    return NULL;
}

static JVal *json_parse(const char *src, const char **error) {
    Parser p = {src, NULL};
    JVal *v = parse_value(&p);

    ws(&p);
    if (v && *p.p != '\0') {
        freeval(v);
        v = NULL;
        p.error = "Extra characters after JSON value";
    }

    if (!v && !p.error) p.error = "Out of memory";
    if (error) *error = p.error;
    return v;
}

int main(void) {
    const char *src =
        "{\"name\":\"HashTool\",\"enabled\":true,"
        "\"count\":3,\"items\":[1,2,null]}";

    const char *error = NULL;
    JVal *root = json_parse(src, &error);

    if (!root) {
        fprintf(stderr, "Parse error: %s\n",
                error ? error : "Unknown error");
        return 1;
    }

    printf("JSON parsed successfully.\n");
    printf("Root type: %d\n", root->type);

    for (size_t i = 0; i < root->as.object.count; i++) {
        JPair *pair = &root->as.object.items[i];
        printf("Key: %s, type: %d\n",
               pair->key, pair->value->type);
    }

    freeval(root);
    return 0;
}
